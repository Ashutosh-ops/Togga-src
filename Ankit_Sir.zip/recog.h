
// recog.h

#ifndef RECOG_H
#define RECOG_H

// includes

#include "board.h"
#include "util.h"

// functions

extern bool recog_draw (const board_t * board, int ThreadId);

#endif // !defined RECOG_H

// end of recog.h

